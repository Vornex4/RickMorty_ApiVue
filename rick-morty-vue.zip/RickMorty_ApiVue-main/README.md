# RickMorty_ApiVue
Api creada mediante Vue y Boostrap
